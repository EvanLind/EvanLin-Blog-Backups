#coding:utf-8
from django.contrib import admin
from Blog.models import Article, Category, Carousel, Comment, Notification


class CarouselAdmin(admin.ModelAdmin):
    search_fields = ('title',)
    list_display = ('title', 'article', 'img', 'create_time')
    list_filter = ('create_time',)
    fields = ('title', 'article', 'img',)


class CategoryAdmin(admin.ModelAdmin):
    search_fields = ('name',)
    list_filter = ('status', 'create_time')
    list_display = ('name', 'parent', 'rank', 'status', )
    fields = ('name', 'img', 'parent', 'rank', 'status', 'summary')


class ArticleAdmin(admin.ModelAdmin):
    search_fields = ('title',)
    list_filter = ('status', 'category', 'create_time', 'view_times',)
    list_display = ('title', 'category', 'create_time', 'status',)
    fieldsets = (
        (u'基本信息', {'fields': ('title', 'en_title', 'view_times', 'category', 'tags', 'status',)}),
        (u'内容', {'fields': ('content',)}),
        (u'时间', {'fields': ('create_time',)}),
    )


class CommentAdmin(admin.ModelAdmin):
    search_fields = ('user__username', 'article__title', 'text')
    list_filter = ('create_time',)
    list_display = ('user', 'article', 'parent', 'create_time')
    fields = ('user', 'article', 'parent', 'text')


class NotificationAdmin(admin.ModelAdmin):
    search_fields = ('text',)
    list_display = ('title', 'from_user', 'to_user', 'create_time')
    list_filter = ('create_time',)
    fields = ('title', 'is_read', 'text', 'url', 'from_user', 'to_user', 'type')

admin.site.register(Notification, NotificationAdmin)
admin.site.register(Category, CategoryAdmin)
admin.site.register(Article, ArticleAdmin)
admin.site.register(Carousel, CarouselAdmin)
admin.site.register(Comment, CommentAdmin)
