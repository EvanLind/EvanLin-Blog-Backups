# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='Article',
            fields=[
                ('id', models.AutoField(serialize=False, auto_created=True, primary_key=True, verbose_name='ID')),
                ('title', models.CharField(max_length=100, verbose_name='标题')),
                ('en_title', models.CharField(max_length=100, verbose_name='英文标题')),
                ('img', models.CharField(max_length=200, default='/static/img/article/default.jpg')),
                ('tags', models.CharField(null=True, max_length=200, help_text='用逗号分隔', blank=True, verbose_name='标签')),
                ('content', models.TextField(verbose_name='正文')),
                ('view_times', models.IntegerField(default=0, verbose_name='浏览次数')),
                ('create_time', models.DateTimeField(default=False, verbose_name='创建时间')),
                ('status', models.IntegerField(choices=[(0, '正常'), (1, '草稿'), (2, '删除')], default=0, verbose_name='状态')),
            ],
            options={
                'ordering': ['-create_time', 'view_times'],
                'verbose_name': '文章',
                'verbose_name_plural': '文章',
            },
        ),
        migrations.CreateModel(
            name='Carousel',
            fields=[
                ('id', models.AutoField(serialize=False, auto_created=True, primary_key=True, verbose_name='ID')),
                ('title', models.CharField(max_length=100, verbose_name='标题')),
                ('img', models.CharField(max_length=200, default='/static/img/carousel/default.jpg', verbose_name='轮播图片')),
                ('create_time', models.DateTimeField(auto_now_add=True, verbose_name='创建时间')),
                ('article', models.ForeignKey(to='Blog.Article', verbose_name='文章')),
            ],
            options={
                'ordering': ['-create_time'],
                'verbose_name': '轮播',
                'verbose_name_plural': '轮播',
            },
        ),
        migrations.CreateModel(
            name='Category',
            fields=[
                ('id', models.AutoField(serialize=False, auto_created=True, primary_key=True, verbose_name='ID')),
                ('name', models.CharField(max_length=40, verbose_name='名称')),
                ('summary', models.TextField(default='Test', verbose_name='专栏摘要')),
                ('rank', models.IntegerField(default=0, verbose_name='排序')),
                ('status', models.IntegerField(choices=[(0, '正常'), (1, '草稿'), (2, '删除')], default=0, verbose_name='状态')),
                ('create_time', models.DateTimeField(auto_now_add=True, verbose_name='创建时间')),
                ('parent', models.ForeignKey(null=True, blank=True, verbose_name='上级专栏', default=None, to='Blog.Category')),
            ],
            options={
                'ordering': ['rank', '-create_time'],
                'verbose_name': '专栏',
                'verbose_name_plural': '专栏',
            },
        ),
        migrations.CreateModel(
            name='Comment',
            fields=[
                ('id', models.AutoField(serialize=False, auto_created=True, primary_key=True, verbose_name='ID')),
                ('comment', models.TextField(verbose_name='评论内容')),
                ('create_time', models.DateTimeField(auto_now_add=True, verbose_name='创建时间')),
                ('article', models.ForeignKey(to='Blog.Article', verbose_name='文章')),
                ('user', models.ForeignKey(to=settings.AUTH_USER_MODEL, verbose_name='用户')),
            ],
            options={
                'ordering': ['-create_time'],
                'verbose_name': '评论',
                'verbose_name_plural': '评论',
            },
        ),
        migrations.AddField(
            model_name='article',
            name='category',
            field=models.ForeignKey(verbose_name='分类', default=None, to='Blog.Category'),
        ),
    ]
