# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('Blog', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='Notification',
            fields=[
                ('id', models.AutoField(primary_key=True, verbose_name='ID', serialize=False, auto_created=True)),
                ('title', models.CharField(max_length=100, verbose_name='标题')),
                ('text', models.TextField(verbose_name='内容')),
                ('url', models.CharField(max_length=200, verbose_name='连接', blank=True, null=True)),
                ('type', models.CharField(max_length=20, verbose_name='类型', blank=True, null=True)),
                ('is_read', models.IntegerField(verbose_name='是否读过', choices=[(0, '未读'), (1, '已读')], default=0)),
                ('create_time', models.DateTimeField(auto_now_add=True, verbose_name='创建时间')),
            ],
            options={
                'verbose_name': '消息',
                'verbose_name_plural': '消息',
                'ordering': ['-create_time'],
            },
        ),
    ]
