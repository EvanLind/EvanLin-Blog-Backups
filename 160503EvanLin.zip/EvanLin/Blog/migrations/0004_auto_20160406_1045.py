# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('Blog', '0003_auto_20160406_0252'),
    ]

    operations = [
        migrations.RenameField(
            model_name='comment',
            old_name='comment',
            new_name='text',
        ),
        migrations.AddField(
            model_name='comment',
            name='parent',
            field=models.ForeignKey(verbose_name='引用', null=True, blank=True, default=None, to='Blog.Comment'),
        ),
    ]
