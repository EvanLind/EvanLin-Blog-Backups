# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('Blog', '0004_auto_20160406_1045'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='article',
            name='img',
        ),
        migrations.AddField(
            model_name='category',
            name='img',
            field=models.CharField(default=b'/static/img/article/Category/default.png', max_length=200, verbose_name='\u56fe\u7247'),
        ),
        migrations.AlterField(
            model_name='article',
            name='category',
            field=models.ForeignKey(default=None, verbose_name=b'\xe5\x88\x86\xe7\xb1\xbb', to='Blog.Category'),
        ),
        migrations.AlterField(
            model_name='category',
            name='status',
            field=models.IntegerField(default=0, verbose_name=b'\xe7\x8a\xb6\xe6\x80\x81', choices=[(0, '\u6b63\u5e38'), (1, '\u8349\u7a3f'), (2, '\u5220\u9664')]),
        ),
    ]
