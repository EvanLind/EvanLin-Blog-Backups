#coding:utf-8
from django.db import models
from django.conf import settings
from django.core.urlresolvers import reverse

STATUS = {
        0: u'正常',
        1: u'草稿',
        2: u'删除',
}

class StringWithTitle(str):
    """ 用来修改admin中显示的app名称,因为admin app 名称是用 str.title()显示的,
    所以修改str类的title方法就可以实现.
    """
    def __new__(cls, value, title):
        instance = str.__new__(cls, value)
        instance._title = title
        return instance

    def title(self):
        return self.title

    __copy__ = lambda self: self
    __deepcopy__ = lambda self, memodict: self


class Category(models.Model):
    name = models.CharField(max_length=40, verbose_name=u'名称')
    summary = models.TextField(default='Test', verbose_name=u'专栏摘要')
    parent = models.ForeignKey('self', default=None, blank=True, null=True, verbose_name=u'上级专栏')
    rank = models.IntegerField(default=0, verbose_name=u'排序')
    status = models.IntegerField(default=0, choices=STATUS.items(), verbose_name='状态')
    create_time = models.DateTimeField(u'创建时间', auto_now_add=True)
    img = models.ImageField(u'图片', null=True, blank=True,  upload_to='static/img/category', default='/static/img/article/Category/default.png')

    class Meta:
        verbose_name_plural = verbose_name = u'专栏'
        ordering = ['rank', '-create_time']
        app_label = StringWithTitle('Blog', u"博客管理")

    def get_absolute_url(self):
        return reverse('category-detail-view', args=(self.name,))

    def __unicode__(self):
        if self.parent:
            return '%s-->%s' % (self.parent, self.name)
        else:
            return '%s' % (self.name,)

    __str__ = __unicode__


class Article(models.Model):
    category = models.ForeignKey(Category, default=None, verbose_name='分类')
    title = models.CharField(max_length=100, verbose_name=u'标题')
    en_title = models.CharField(max_length=100, verbose_name=u'英文标题')#slug,生成网页合法链接
    tags = models.CharField(max_length=200, null=True, blank=True, verbose_name=u'标签', help_text=u'用逗号分隔')
    content = models.TextField(verbose_name=u'正文')
    view_times = models.IntegerField(default=0, verbose_name=u'浏览次数')
    create_time = models.DateTimeField(default=False, verbose_name=u'创建时间')
    status = models.IntegerField(default=0, choices=STATUS.items(), verbose_name=u'状态')

    def get_tags(self):
        return self.tags.split(',')

    class Meta:
        verbose_name_plural = verbose_name = u'文章'
        ordering = ['-create_time', 'view_times']
        app_label = StringWithTitle('Blog', u'博客管理')

    def get_absolute_url(self):
        return reverse('article-detail-view', args=(self.en_title,))

    def __unicode__(self):
        return self.title

    __str__ = __unicode__


class Carousel(models.Model):
    title = models.CharField(max_length=100, verbose_name=u'标题')
    img = models.ImageField(u'图片', null=True, blank=True,  upload_to='static/img/carousel', default='/static/img/carousel/default.png')
    article = models.ForeignKey(Article, verbose_name=u'文章')
    create_time = models.DateTimeField(u'创建时间', auto_now_add=True)

    class Meta:
        verbose_name_plural = verbose_name = u'轮播'
        ordering = ['-create_time']
        app_label = StringWithTitle('Blog', u"博客管理")


class Comment(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, verbose_name=u'用户')
    article = models.ForeignKey(Article, verbose_name=u'文章')
    text = models.TextField(verbose_name=u'评论内容')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name=u'创建时间')
    parent = models.ForeignKey('self', default=None, blank=True, null=True, verbose_name=u'引用')

    class Meta:
        verbose_name_plural = verbose_name = u'评论'
        ordering = ['-create_time']
        app_label = StringWithTitle('Blog', u"评论管理")

    def __unicode__(self):
        return self.article.title + '_' + str(self.pk)

    __str__ = __unicode__


IS_READ = {
        0: u'未读',
        1: u'已读'
}


class Notification(models.Model):
    title = models.CharField(max_length=100, verbose_name=u'标题')
    text = models.TextField(verbose_name=u'内容')
    url = models.CharField(max_length=200, verbose_name=u'连接',
                           null=True, blank=True)
    from_user = models.ForeignKey(settings.AUTH_USER_MODEL,
                                  default=None, blank=True, null=True,
                                  related_name='from_user_notification_set',
                                  verbose_name=u'发送者')
    to_user = models.ForeignKey(settings.AUTH_USER_MODEL,
                                related_name='to_user_notification_set',
                                verbose_name=u'接收者')
    type = models.CharField(max_length=20, verbose_name=u'类型',
                            null=True, blank=True)

    is_read = models.IntegerField(default=0, choices=IS_READ.items(),
                                  verbose_name=u'是否读过')

    create_time = models.DateTimeField(u'创建时间', auto_now_add=True)

    class Meta:
        verbose_name_plural = verbose_name = u'消息'
        ordering = ['-create_time']
