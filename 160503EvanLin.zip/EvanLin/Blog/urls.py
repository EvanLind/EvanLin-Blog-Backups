from django.conf.urls import url
from Blog.views import IndexView, ArticleView, AllArticleView, CommentControl, SearchView, TagView, AboutMe
from django.views.generic import TemplateView

urlpatterns = [
        url(r'^blog/$', IndexView.as_view(), name='index-view'),
        url(r'^blog/article/(?P<slug>\w+).html$', ArticleView.as_view(), name='article-detail-view'),
        url(r'^blog/all/$', AllArticleView.as_view(), name='all-view'),
        url(r'^blog/comment/(?P<slug>\w+)$', CommentControl.as_view()),
        url(r'^blog/search/$', SearchView.as_view()),
        url(r'^blog/tag/(?P<tag>\w+)/$', TagView.as_view(), name='tag-detail-view'),
        url(r'^blog/about/', AboutMe.as_view()),
]
