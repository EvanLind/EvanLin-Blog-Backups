# def findParent(comTree, comobj):
#
#     for com in comobj:
#         if com.parent is None
#             return comTree
#         else:
#             findParent(comTree, com)
#
#
#     for p, v in comTree.items():
#         if p == comobj.parent:
#             comTree[p][comobj] = {}
#         else:
#             findParent(comTree[p], comobj)
#
# commentTree = {}
# def creatCommentTree(comment):
#     for com in comment:
#         if com.parent is None
#
#             return comment
#         else:
#             findParent(comTree, com)
#     findParent(commentTree, comment)
#     return commentTree
#     # for k,v in commentTree:
#     #     print(k, v)


def findParent(comTree, comobj):

    for p, v in comTree.items():
        if p == comobj.parent:
            comTree[p][comobj] = {}
        else:
            findParent(comTree[p], comobj)


def creatCommentTree(comment):

    commentTree = {}
    for com in comment:
        if com.parent is None:
            commentTree[com] = {}
    else:
        findParent(commentTree, com)
    return commentTree



