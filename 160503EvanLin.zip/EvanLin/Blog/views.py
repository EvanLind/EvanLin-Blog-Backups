#coding:utf-8
from django import template
from django.http import HttpResponse, Http404
from django.shortcuts import render, render_to_response
from django.template import Context, loader
from django.views.generic import View, TemplateView, ListView, DetailView
from django.db.models import Q
from django.core.cache import caches
from django.core.exceptions import PermissionDenied
from django.contrib.auth.tokens import default_token_generator
from Blog.models import Article, Category, Comment, Carousel,Notification
from django.conf import settings
import datetime
import logging
import json
from django.core.mail import send_mail
from django.contrib.sites.models import get_current_site
from django.utils.http import urlsafe_base64_decode
import os
import base64

# 缓存
try:
    cache = caches['memcache']
except ImportError as e:
    cache = caches['default']

# logger
logger = logging.getLogger(__name__)


class BaseMixin(object):

    def get_context_data(self, *args, **kwargs):
        context = super(BaseMixin, self).get_context_data(**kwargs)
        try:
            # 热门文章
            context['hot_article_list'] = Article.objects.filter(status=0).order_by("-view_times")[0:6]
            # 最新评论
            context['latest_comment_list'] = Comment.objects.order_by("-create_time")[0:6]
            # tags云
            # context['tags'] = settings.WEBSITE_TAGS
            all_tag = Article.objects.values('tags')
            tag_list = []
            for i in all_tag:
                for j in i['tags'].split(','):
                    tag_list.append(j)
            context['tags'] = list(set(tag_list))
            # 用户未读消息数
            user = self.request.user
            if user.is_authenticated():
                context['notification_count'] = user.to_user_notification_set.filter(is_read=0).count()
        except Exception as e:
            logger.error(u'[BaseMixin]加载基本信息出错')
        return context


class IndexView(BaseMixin, ListView):
    template_name = './Blog/index.html'
    context_object_name = 'article_list'
    paginate_by = settings.PAGE_NUM  # 分页--每页的数目

    def get_context_data(self, **kwargs):
        # 轮播
        kwargs['carousel_page_list'] = Carousel.objects.all()
        return super(IndexView, self).get_context_data(**kwargs)

    def get_queryset(self):
        article_list = Article.objects.filter(status=0)
        return article_list


class ArticleView(BaseMixin, DetailView):
    queryset = Article.objects.filter(status=0)
    template_name = './Blog/article.html'
    context_object_name = 'article'
    slug_field = 'en_title'
    # The 46 Year Old Virgin 但是Url 会把它空格看成%20 , 所以使用slug 在中间以 - 链接起来 变成 the-46-year-old-virgin 形式
    # http://stackoverflow.com/questions/427102/what-is-a-slug-in-django

    def get(self, request, *args, **kwargs):
        # 统计文章的访问访问次数
        if 'HTTP_X_FORWARDED_FOR' in request.META:
            ip = request.META['HTTP_X_FORWARDED_FOR']
        else:
            ip = request.META['REMOTE_ADDR']
        self.cur_user_ip = ip
        en_title = self.kwargs.get('slug', '')
        # 获取15*60s时间内访问过这篇文章的所有ip
        visited_ips = cache.get(en_title,[])

        # 如果ip不存在就把文章的浏览次数+1
        if ip not in visited_ips:
            try:
                article = self.queryset.get(en_title=en_title)
            except Article.DoesNotExist:
                logger.error(u'[ArticleView]访问不存在的文章:[%s]' % en_title)
                raise Http404
            else:
                article.view_times += 1
                article.save()
                visited_ips.append(ip)
            cache.set(en_title, visited_ips, 15*60)

        return super(ArticleView, self).get(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        # 评论
        en_title = self.kwargs.get('slug', '')
        kwargs['comment_list'] = self.queryset.get(en_title=en_title).comment_set.all()
        return super(ArticleView, self).get_context_data(**kwargs)


class AllArticleView(BaseMixin, ListView):
    template_name = 'Blog/allArticle.html'
    context_object_name = 'article_list'

    def get_context_data(self, **kwargs):
        kwargs['category_list'] = Category.objects.all()
        kwargs['PAGE_NUM'] = settings.PAGE_NUM
        return super(AllArticleView, self).get_context_data(**kwargs)

    def get_queryset(self):
        article_list = Article.objects.filter(status=0)[0:settings.PAGE_NUM]
        return article_list

    def post(self, request, *args, **kwargs):
        val = self.request.POST.get('val', '')
        sort = self.request.POST.get('sort', '')
        start = self.request.POST.get('start', 0)
        end = self.request.POST.get('end', settings.PAGE_NUM)

        start = int(start)
        end = int(end)

        if sort == 'time':
            sort = '-create_time'
        elif sort == 'recommend':
            sort = '-view_times'
        else:
            sort = '-create_time'

        if val == 'all':
            article_list = Article.objects.filter(status=0).order_by(sort)[start:end+1]
            html = ''
        else:
            try:
                article_list = Category.objects.get(name=val).article_set.filter(status=0).order_by(sort)[start:end+1]
                html = '<div class="all-post clearfix underline">' + Category.objects.get(name=val).summary + '</div>'
            except Category.DoesNotExist:
                logger.error(u'[AllArticleView]此分类不存在:[%s]' %val)
                raise PermissionDenied

        isend = len(article_list) != (end-start+1)
        article_list = article_list[0:end-start]

        for article in article_list:
            html += template.loader.get_template('Blog/all_post.html').render(template.Context({'post': article}))

        myDict = {'html': html, 'isend': isend}
        return HttpResponse(json.dumps(myDict), content_type='application/json')


ArticleModel = Article


class CommentControl(View):
    def post(self, request, *args, **kwargs):
        # 获取当前用户
        user = self.request.user
        # 获取评论
        text = self.request.POST.get("comment", "")
        # 判断当前用户是否是活动的用户
        if not user.is_authenticated():
            logger.error(u'[CommentControl]当前用户非活动用户:[{}]'.format(user.username))
            return HttpResponse(u"请登录！", status=403)

        en_title = self.kwargs.get('slug', '')
        try:
            # 默认使用pk来索引(也可根据需要使用title,en_title在索引
            article = ArticleModel.objects.get(en_title=en_title)
        except ArticleModel.DoesNotExist:
            logger.error(u'[CommentControl]此文章不存在:[%s]' % en_title)
            raise PermissionDenied

        # 保存评论
        parent = None
        if text.startswith('@['):
            import ast
            parent_str = text[1:text.find(':')]
            parent_id = ast.literal_eval(parent_str)[1]
            text = text[text.find(':')+2:]
            try:
                parent = Comment.objects.get(pk=parent_id)
                info = u'{}回复了你在 {} 的评论'.format(user.username, parent.article.title)
                Notification.objects.create(title=info, text=text, from_user=user, to_user=parent.user, url='/article/'+en_title+'.html')
            except Comment.DoesNotExist:
                logger.error(u'[CommentControl]评论引用错误:%s' % parent_str)
                return HttpResponse(u"请勿修改评论代码！", status=403)

        if not text:
            logger.error(u'[CommentControl]当前用户输入空评论:[{}]'.format(user.username))
            return HttpResponse(u"请输入评论内容！", status=403)

        comment = Comment.objects.create(user=user, article=article, text=text, parent=parent)

        try:
            img = comment.user.img
        except Exception as e:
            img = "http://Evan.qiniudn.com/image/tx/tx-default.jpg"

        print_comment = u"<p>评论：{}</p>".format(text)
        if parent:
            print_comment = u"<div class=\"comment-quote\">\
                                  <p>\
                                      <a>@{}</a>\
                                      {}\
                                  </p>\
                              </div>".format(
                                  parent.user.username,
                                  parent.text
                              ) + print_comment
        # 返回当前评论
        html = u"<li>\
                    <div class=\"Evan-comment-tx\">\
                        <img src={} width=\"40\"></img>\
                    </div>\
                    <div class=\"Evan-comment-content\">\
                        <a><h1>{}</h1></a>\
                        {}\
                        <p>{}</p>\
                    </div>\
                </li>".format(
                    img,
                    comment.user.username,
                    print_comment,
                    datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                )

        return HttpResponse(html)


class SearchView(BaseMixin, ListView):
    template_name = 'Blog/search.html'
    context_object_name = 'article_list'
    paginate_by = settings.PAGE_NUM

    def get_context_data(self, **kwargs):
        kwargs['s'] = self.request.GET.get('s', '')
        return super(SearchView, self).get_context_data(**kwargs)

    def get_queryset(self):
        # 获取搜索的关键字
        s = self.request.GET.get('s', '')
        # 在文章的标题,summary和tags中搜索关键字
        article_list = Article.objects.only('title', 'content', 'tags').filter(Q(title__icontains=s) | Q(content__icontains=s) | Q(tags__icontains=s), status=0)
        return article_list


class TagView(BaseMixin, ListView):
    template_name = 'Blog/tag.html'
    context_object_name = 'article_list'
    paginate_by = settings.PAGE_NUM

    def get_queryset(self):
        tag = self.kwargs.get('tag', '')
        article_list = Article.objects.only('tags').filter(tags__icontains=tag, status=0)
        return article_list


class AboutMe(BaseMixin, ListView):
    template_name = 'Blog/about.html'
    context_object_name = 'article_list'

    def get_queryset(self):
        article_list = Article.objects.all()
        return article_list
