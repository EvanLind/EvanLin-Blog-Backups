from django.conf.urls import url
from Store.views import OKSteelsIndex

urlpatterns = [
    url(r'^$', OKSteelsIndex),
]
