from django.shortcuts import render


def OKSteelsIndex(request):
   return render(request, './Store/index.html')
