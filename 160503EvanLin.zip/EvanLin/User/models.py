#coding:utf-8
from django.db import models
from django.contrib.auth.models import AbstractUser


class StringWithTitle(str):
    def __new__(cls, value, title):
        instance = str.__new__(cls, value)
        instance._title = title
        return instance

    def title(self):
        return self.title

    __copy__ = lambda self: self
    __deepcopy__ = lambda self, memodict: self


class EvanBlogUser(AbstractUser):
    img = models.CharField(max_length=200, default='/static/img/user/default.png', verbose_name=u'头像地址')

    class Meta(AbstractUser.Meta):
        app_label = StringWithTitle('User', u'用户管理')
