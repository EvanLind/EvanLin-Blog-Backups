#codeing:utf-8
from django.conf.urls import url
from User.views import EvanBlogUserView
from django.views.generic import TemplateView
urlpatterns = [
    url(r'^blog/user/(?P<slug>\w+)$', EvanBlogUserView.as_view(), name='user-view'),
    url(r'^blog/login/$', TemplateView.as_view(template_name="User/login.html"), name='login-view'),
    url(r'^blog/register/$', TemplateView.as_view(template_name="User/register.html"), name='register-view'),
    url(r'^blog/forgetpassword/$', TemplateView.as_view(template_name="User/forgetPassword.html"), name='forgetpassword-view'),
    url(r'^blog/resetpassword/(?P<uidb64>[0-9A-Za-z_\-]+)/(?P<token>.+)/$', TemplateView.as_view(template_name="User/resetPassword.html"), name='resetpassword-view'),
]

