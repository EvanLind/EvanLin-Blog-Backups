tinymce.addI18n('en',{
	'SH4TinyMCE - Code Editor'	: 'SH4TinyMCE - Code Editor',
	'Insert/Edit Code'			: 'Insert/Edit Code',
	'Language'					: 'Language',
	'Auto links'				: 'Auto links',
	'Gutter'					: 'Gutter',
	'Html script'				: 'HTML script',
	'Toolbar'					: 'Toolbar',
	'Highlight'					: 'Highlight',
	'Tab size'					: 'Tab size',
	'First Line'				: 'First Line',
});
